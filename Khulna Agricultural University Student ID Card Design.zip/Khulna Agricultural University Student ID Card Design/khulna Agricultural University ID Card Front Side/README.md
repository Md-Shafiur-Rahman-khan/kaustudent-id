# KIIT Digital ID Card Builder v1.0.0
![image](https://user-images.githubusercontent.com/79497113/151593953-85951a64-1bed-458c-b2ad-4838c2c085d1.png)

© 2021 KIIT Digital ID Card Builder | Developed by Aryamitra Chaudhuri <br>

# NOTE
NOTE: THIS IS NOT AN OFFICIAL OR AUTHORIZED APP FROM KIIT, MADE FOR DEVELOPMENT PURPOSES ONLY. THIS APPLICATION DOES NOT SAVE ANY DATA FROM USER TO THE SERVER.
THIS APP IS NOT MADE RESPONSIVE, VISIT DESKTOP MODE ONLY.

# LIVE PREVIEW
https://www.aryamitrachaudhuri.com/KIIT-digital-id-card-builder/

# DESCRIPTION
You can fill your KIIT id card details to the website form and it'll generate automatically an digital ID card looking exactly same with your original hard ID card.
You can download your id card in .png format directly from the website.
